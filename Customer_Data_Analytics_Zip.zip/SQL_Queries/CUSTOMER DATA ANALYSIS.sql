use project_customer_segmentation;
show tables;
select * from customer;

desc customer;
# 1. HOW IS THE SHOPPING DISTRIBUTION ACCORDING TO GENDER? 
SELECT gender, COUNT(*) AS total_orders, ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM customer), 2) AS percentage_share
FROM customer
GROUP BY gender
ORDER BY total_orders DESC;

# 2. WHICH GENDER DID WE SELL MORE PRODUCTS TO?
select * from customer;
select gender, sum(quantity) as total_sell 
from customer
group by gender
order by total_sell desc;

# 3. WHICH GENDER GENERATED MORE REVENUE? 
select * from customer;
SELECT gender, sum(quantity * price) as total_revenue , round(count(*) * 100 / (select count(*) from customer ),2) as share_revenue 
FROM customer 
GROUP BY gender
ORDER BY total_revenue DESC;

# 4. DISTRIBUTION OF PURCHASE CATEGORIES RELATIVE TO OTHER COLUMNS?
select * from customer;

#categories vs gender
SELECT category, gender, COUNT(*) AS order_count, SUM(quantity) AS total_units,
ROUND(SUM(quantity * price), 2) AS total_revenue
FROM customer
GROUP BY category, gender
ORDER BY category, total_revenue DESC;

# category vs shopping mall
SELECT shopping_mall, category, COUNT(*) AS total_transactions, ROUND(SUM(quantity * price), 2) AS total_revenue
FROM customer
GROUP BY shopping_mall, category
ORDER BY shopping_mall, total_revenue DESC;

# 5. HOW IS THE SHOPPING DISTRIBUTION ACCORDING TO AGE?
SELECT
CASE
WHEN age < 25 THEN 'Under 25'
WHEN age BETWEEN 25 AND 39 THEN '25-39'
WHEN age BETWEEN 40 AND 54 THEN '40-54'
ELSE '55 and Above'
END AS age_group,
COUNT(*) AS total_orders,
ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM customer), 2) AS percentage_share
FROM customer
GROUP BY age_group
ORDER BY total_orders DESC;   

-- 6. WHICH AGE CAT DID WE SELL MORE PRODUCTS TO?
SELECT
CASE
WHEN age < 25 THEN 'Under 25'
WHEN age BETWEEN 25 AND 39 THEN '25-39'
WHEN age BETWEEN 40 AND 54 THEN '40-54'
ELSE '55 and Above'
END AS age_group,
SUM(quantity) AS total_products_sold,
ROUND(SUM(quantity) * 100.0 / (SELECT SUM(quantity) FROM customer), 2) AS percentage_share
FROM customer
GROUP BY age_group
ORDER BY total_products_sold DESC;   

-- 7. WHICH AGE CAT GENERATED MORE REVENUE?
SELECT
CASE
WHEN age < 25 THEN 'Under 25'
WHEN age BETWEEN 25 AND 39 THEN '25-39'
WHEN age BETWEEN 40 AND 54 THEN '40-54'
ELSE '55 and Above'
END AS age_group,
ROUND(SUM(quantity * price), 2) AS total_revenue,
ROUND(SUM(quantity * price) * 100.0 / (SELECT SUM(quantity * price) FROM customer), 2) AS revenue_share_pct
FROM customer
GROUP BY age_group
ORDER BY total_revenue DESC;   

-- 8. DISTRIBUTION OF PURCHASE CATEGORIES RELATIVE TO OTHER COLUMNS?
SELECT
shopping_mall,
category,
COUNT(*) AS total_transactions,
ROUND(SUM(quantity * price), 2) AS total_revenue
FROM customer
GROUP BY shopping_mall, category
ORDER BY shopping_mall, total_revenue DESC;   

-- 9. DOES THE PAYMENT METHOD HAVE A RELATION WITH OTHER COLUMNS?
SELECT
payment_method,
COUNT(*) AS transaction_count,
ROUND(AVG(quantity * price), 2) AS avg_transaction_value,
ROUND(SUM(quantity * price), 2) AS total_revenue
FROM customer
GROUP BY payment_method
ORDER BY total_revenue DESC;   

-- 10. HOW IS THE DISTRIBUTION OF THE PAYMENT METHOD?
SELECT
payment_method,
COUNT(*) AS transaction_count,
ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM customer), 2) AS percentage_share
FROM customer
GROUP BY payment_method
ORDER BY transaction_count DESC;